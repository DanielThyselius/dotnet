﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lecture1
{
    class Collar
    {
        public string Color { get; set; }
        public string Material { get; set; }
    }
}
