﻿namespace ExempelInterfaces
{
    interface IMovable
    {
        int PositionX { get; set; }
        int PositionY { get; set; }
    }
}