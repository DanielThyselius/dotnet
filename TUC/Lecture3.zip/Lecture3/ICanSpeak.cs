﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lecture3
{
    interface ICanSpeak
    {
        void Speak();
    }
}
