﻿namespace Lecture3
{
    internal interface IAlive
    {
        int Age { get; set; }
    }
}