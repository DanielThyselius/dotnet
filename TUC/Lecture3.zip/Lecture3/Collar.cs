﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lecture3
{
    class Collar
    {
        public string Color { get; set; }
        public string Material { get; set; }
    }
}
